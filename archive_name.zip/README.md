# NFT Subgraph

An experimental subgraph that indexes NFTs on the Ethereum blockchain.
